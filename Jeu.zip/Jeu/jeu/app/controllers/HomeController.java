package controllers;

import play.mvc.*;

import models.*;

import javax.inject.Inject;
import play.i18n.MessagesApi;
import play.data.*;

import views.html.*;
import play.data.validation.Constraints.*;

import java.util.List;
/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */    

    @Inject
    FormFactory formFactory;
    Form<Jeu> jeuForm;
    MessagesApi messagesApi;
    
    @Inject
    public HomeController(FormFactory formFactory, MessagesApi messagesApi){
        this.jeuForm = formFactory.form(Jeu.class);
        this.messagesApi = messagesApi;
    }
    
    public Result index() {
        return ok(views.html.index.render());
    }
    
    
    public Result ajoutJeu(Http.Request request){
        return ok(views.html.ajoutJeu.render(jeuForm,request,messagesApi.preferred(request)));
    }
    
    public Result jeuOk(Http.Request request){
        Form<Jeu> lform = jeuForm.bindFromRequest(request);
        if (lform.hasErrors()){
            return badRequest(ajoutJeu.render(lform, request, messagesApi.preferred(request)));
        } else {
        Jeu jeu = lform.get();
            jeu.save();
        return redirect(routes.HomeController.all());
        }
    
    }
 
    public Result all(){
        List<Jeu> liste = Jeu.find.all();
        return ok(all.render(liste));
    }
    
    public Result show(Long id){
        Jeu jeu = Jeu.find.byId(id);
        return ok(show.render(jeu));
    }
    
    public Result delete(Long id){
        Jeu jeu = Jeu.find.byId(id);
        jeu.delete();
        return redirect (routes.HomeController.all());
    }
    
    public Result update(Long id, Http.Request request){
         Jeu jeu = Jeu.find.byId(id);
         jeuForm = jeuForm.fill(jeu);
         return ok(update.render(jeuForm, id, request, messagesApi.preferred(request)));
    }
    
     public Result updateOk(Long id, Http.Request request){
         Form<Jeu> lform = jeuForm.bindFromRequest(request);
        if (lform.hasErrors()){
            return badRequest(update.render(lform, id, request, messagesApi.preferred(request)));
        } else {
        Jeu jeu = lform.get();
            jeu.setId(id);
            jeu.update();
        return redirect(routes.HomeController.all());
        }
    } 
    
    
    
}
