# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table jeux (
  id                            bigint auto_increment not null,
  nom                           varchar(255),
  age                           integer not null,
  date_crea                     timestamp,
  créateur                      varchar(255),
  desc                          varchar(255),
  constraint pk_jeux primary key (id)
);


# --- !Downs

drop table if exists jeux;

